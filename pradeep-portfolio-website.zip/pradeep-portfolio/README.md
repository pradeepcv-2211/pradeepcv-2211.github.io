# Pradeep — Personal Portfolio

A responsive personal portfolio website with a modern dark theme.

## Included sections
- Introduction / hero
- About me
- Skills: C, Python, HTML, CSS
- Project: RESQNET (clearly marked as in development)
- Career interests: AI and Software Development
- Contact / connection note

## Files
- `index.html` — page content and structure
- `style.css` — theme, layout, and responsive styling
- `script.js` — mobile navigation and current year

## Run locally
Open `index.html` in a web browser. No build tools or package installation are required.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new **public** repository. For a personal site, name it exactly `YOUR-USERNAME.github.io` (replace `YOUR-USERNAME` with your actual GitHub username). Alternatively, use any repository name for a project site.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository's root folder.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for the Pages deployment to finish. Your personal-site address will be `https://YOUR-USERNAME.github.io/`. A project site usually uses `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.
7. After updating files, push or upload the changes to the selected branch; GitHub Pages will publish them.

## Before publishing
- Add your GitHub profile URL once you know your username.
- Add a professional email or contact link if you want visitors to contact you.
- Update the RESQNET description as real features are implemented. Do not describe planned features as completed work.
- Replace any wording that no longer reflects your current skills or project progress.

## Customization
Edit the text in `index.html` and visual styles in `style.css`. The page uses Google Fonts when an internet connection is available; fallback fonts are included.
